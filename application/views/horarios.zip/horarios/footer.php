
<div id="footer-sec">
        &copy; FEI | :D
    </div>
    <!-- /. FOOTER  -->
    <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
    <!-- JQUERY SCRIPTS -->
    <script src="<?=base_url()?>js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS -->
    <script src="<?=base_url()?>js/bootstrap.js"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?=base_url()?>js/jquery.metisMenu.js"></script>
       <!-- CUSTOM SCRIPTS -->
    <script src="<?=base_url()?>js/custom.js"></script>
    


</body>
</html>
